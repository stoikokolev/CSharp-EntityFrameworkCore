﻿namespace P03_FootballBetting.Data
{
    internal static class DataSettings
    {
        internal static string DefaultConnection =
            "Server=STOYKO-PC\\SQLEXPRESS;Database=FootballBettingSystem;Integrated Security = True";
    }
}